import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() => runApp(const AlwosolLilMasjid());

class AlwosolLilMasjid extends StatelessWidget {
  const AlwosolLilMasjid({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'الوصول إلى المسجد',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorSchemeSeed: const Color(0xFF176B4D),
      ),
      home: const HomePage(),
    );
  }
}

class Player {
  Player(this.name, this.color);
  String name;
  final Color color;
  int position = 1;
  int score = 0;
}

enum PathType { fiqh, tawhid, seerah }

class Question {
  const Question(this.text, this.options, this.answer);
  final String text;
  final List<String> options;
  final int answer;
}

class CardData {
  const CardData(this.path, this.title, this.questions);
  final PathType path;
  final String title;
  final List<Question> questions;
}

const List<CardData> cards = [
  CardData(PathType.fiqh, 'بطاقة الفقه 1', [
    Question('كم عدد الصلوات المفروضة في اليوم والليلة؟', ['ثلاث', 'خمس', 'سبع', 'أربع'], 1),
    Question('ما الصلاة التي يبدأ وقتها بطلوع الفجر؟', ['الفجر', 'العصر', 'المغرب', 'العشاء'], 0),
    Question('ما الطهارة التي تكون بالماء؟', ['التيمم', 'الوضوء', 'الاستغفار', 'الصدقة'], 1),
  ]),
  CardData(PathType.fiqh, 'بطاقة الفقه 2', [
    Question('إلى أي جهة يتوجه المسلم في الصلاة؟', ['الشمال', 'الكعبة', 'البحر', 'الشرق دائمًا'], 1),
    Question('ما اسم النداء الذي يُعلن دخول وقت الصلاة؟', ['الخطبة', 'الأذان', 'التلبية', 'الدعاء'], 1),
    Question('كم ركعة في صلاة المغرب؟', ['ركعتان', 'ثلاث ركعات', 'أربع ركعات', 'خمس'], 1),
  ]),
  CardData(PathType.fiqh, 'بطاقة الفقه 3', [
    Question('ما الصلاة التي عدد ركعات فرضها أربع؟', ['الفجر', 'المغرب', 'الظهر', 'الوتر'], 2),
    Question('ما اسم الاغتسال الواجب في بعض أحوال الطهارة؟', ['الغسل', 'الوضوء', 'التيمم', 'السواك'], 0),
    Question('ماذا يفعل من لم يجد الماء أو عجز عن استعماله في بعض الأحوال؟', ['يتيمم', 'يترك الصلاة', 'ينام', 'يؤخرها بلا سبب'], 0),
  ]),
  CardData(PathType.fiqh, 'بطاقة الفقه 4', [
    Question('ما الشهر الذي يصومه المسلمون فرضًا؟', ['شعبان', 'رمضان', 'محرم', 'رجب'], 1),
    Question('ما العبادة التي تتضمن الوقوف بعرفة؟', ['العمرة', 'الحج', 'الاعتكاف', 'الصدقة'], 1),
    Question('ما الركن الذي يبدأ به المسلم عند دخول الصلاة؟', ['التكبير', 'الأذان', 'الزكاة', 'السعي'], 0),
  ]),
  CardData(PathType.fiqh, 'بطاقة الفقه 5', [
    Question('ما اسم الصلاة التي تؤدى يوم الجمعة بدل صلاة الظهر للمستطيعين بشروطها؟', ['صلاة الجمعة', 'صلاة الضحى', 'صلاة الوتر', 'صلاة الاستسقاء'], 0),
    Question('أيّ مما يلي من أوقات الصلوات المفروضة؟', ['الظهر', 'الضحى فقط', 'التهجد فقط', 'التراويح فقط'], 0),
    Question('ما العبادة المالية المفروضة على من ملك النصاب وحال عليه الحول في الأموال الزكوية؟', ['الحج', 'الزكاة', 'الاعتكاف', 'الأضحية فقط'], 1),
  ]),
  CardData(PathType.tawhid, 'بطاقة التوحيد 1', [
    Question('ما معنى توحيد الربوبية؟', ['إفراد الله بأفعاله كالخلق والملك والتدبير', 'إتقان العمل', 'كثرة المال', 'حفظ الشعر'], 0),
    Question('لمن تكون العبادة؟', ['لله وحده', 'لكل أحد', 'للملائكة', 'للنجوم'], 0),
    Question('ما أول أركان الإسلام؟', ['الصيام', 'الشهادة', 'الزكاة', 'الحج'], 1),
  ]),
  CardData(PathType.tawhid, 'بطاقة التوحيد 2', [
    Question('ما معنى شهادة أن محمدًا رسول الله؟', ['طاعته فيما أمر وتصديقه فيما أخبر', 'عبادته من دون الله', 'ترك سنته', 'عدم اتباعه'], 0),
    Question('ما أعظم حق لله على عباده؟', ['أن يعبدوه وحده', 'أن يجمعوا المال', 'أن يسافروا', 'أن يناموا'], 0),
    Question('ما ضد التوحيد؟', ['الشرك', 'الإحسان', 'الصدق', 'الصبر'], 0),
  ]),
  CardData(PathType.tawhid, 'بطاقة التوحيد 3', [
    Question('ما معنى الإخلاص؟', ['أن يكون العمل لله وحده', 'طلب مدح الناس', 'ترك العمل', 'كثرة الكلام'], 0),
    Question('من الذي خلق السماوات والأرض؟', ['الله', 'الناس', 'النجوم', 'الملائكة'], 0),
    Question('أي كلمة تجمع أصل الشهادة؟', ['لا إله إلا الله', 'سبحان الصبح', 'حي على النوم', 'اللهم زد المال'], 0),
  ]),
  CardData(PathType.tawhid, 'بطاقة التوحيد 4', [
    Question('ما معنى العبادة؟', ['اسم جامع لكل ما يحبه الله ويرضاه من الأقوال والأعمال', 'المال فقط', 'الصمت فقط', 'السفر فقط'], 0),
    Question('هل يجوز صرف العبادة لغير الله؟', ['لا', 'نعم دائمًا', 'أحيانًا', 'لا علاقة'], 0),
    Question('ما أثر التوحيد على المسلم؟', ['يزيد صلته بالله ويهديه لإخلاص العبادة', 'يجعله يترك العمل', 'يمنعه من الخير', 'لا أثر له'], 0),
  ]),
  CardData(PathType.tawhid, 'بطاقة التوحيد 5', [
    Question('ما معنى الإيمان بالله؟', ['الإيمان بوجوده وربوبيته وألوهيته وأسمائه وصفاته كما يليق به', 'الإيمان بالمال فقط', 'الإيمان بالناس فقط', 'الإيمان بالنجوم'], 0),
    Question('ما الذي ينافي الإخلاص؟', ['الرياء', 'الصدق', 'الصبر', 'الشكر'], 0),
    Question('إلى من نتوكل في العبادة؟', ['على الله', 'على الحظ', 'على النجوم', 'على الصدفة'], 0),
  ]),
  CardData(PathType.seerah, 'بطاقة السيرة 1', [
    Question('أين وُلد النبي محمد ﷺ؟', ['مكة', 'المدينة', 'الطائف', 'القدس'], 0),
    Question('إلى أين هاجر النبي ﷺ من مكة؟', ['المدينة', 'اليمن', 'الشام', 'مصر'], 0),
    Question('ما اسم والد النبي ﷺ؟', ['عبد الله', 'أبو طالب', 'عبد المطلب', 'حمزة'], 0),
  ]),
  CardData(PathType.seerah, 'بطاقة السيرة 2', [
    Question('من أول زوجات النبي ﷺ؟', ['خديجة رضي الله عنها', 'عائشة رضي الله عنها', 'حفصة رضي الله عنها', 'صفية رضي الله عنها'], 0),
    Question('من صاحب النبي ﷺ في الهجرة؟', ['أبو بكر الصديق رضي الله عنه', 'عمر رضي الله عنه', 'عثمان رضي الله عنه', 'علي رضي الله عنه'], 0),
    Question('ما اسم الغار الذي اختبأ فيه النبي ﷺ وأبو بكر أثناء الهجرة؟', ['غار حراء', 'غار ثور', 'غار أحد', 'غار بدر'], 1),
  ]),
  CardData(PathType.seerah, 'بطاقة السيرة 3', [
    Question('ما أول مسجد أسسه النبي ﷺ بعد الهجرة؟', ['مسجد قباء', 'المسجد الحرام', 'المسجد الأقصى', 'مسجد الخيف'], 0),
    Question('ما اسم أم النبي ﷺ؟', ['آمنة بنت وهب', 'حليمة السعدية', 'فاطمة الزهراء', 'صفية بنت عبد المطلب'], 0),
    Question('ما لقب النبي ﷺ قبل البعثة؟', ['الصادق الأمين', 'الفاروق', 'ذو النورين', 'سيف الله'], 0),
  ]),
  CardData(PathType.seerah, 'بطاقة السيرة 4', [
    Question('في أي مدينة توفي النبي ﷺ؟', ['المدينة المنورة', 'مكة', 'الطائف', 'بدر'], 0),
    Question('ما اسم أول الخلفاء الراشدين؟', ['أبو بكر الصديق رضي الله عنه', 'عمر رضي الله عنه', 'عثمان رضي الله عنه', 'علي رضي الله عنه'], 0),
    Question('ما اسم المعركة التي وقعت في السنة الثانية للهجرة؟', ['بدر', 'أحد', 'الخندق', 'حنين'], 0),
  ]),
  CardData(PathType.seerah, 'بطاقة السيرة 5', [
    Question('ما اسم المدينة التي كانت تُعرف بيثرب؟', ['المدينة المنورة', 'مكة', 'الطائف', 'خيبر'], 0),
    Question('من مرضعة النبي ﷺ من بني سعد؟', ['حليمة السعدية', 'آمنة بنت وهب', 'خديجة', 'صفية'], 0),
    Question('كم سنة تقريبًا مكث النبي ﷺ في مكة بعد البعثة قبل الهجرة؟', ['13 سنة', '3 سنوات', '20 سنة', '40 سنة'], 0),
  ]),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final names = List.generate(4, (i) => TextEditingController(text: 'اللاعب ${i + 1}'));

  @override
  void dispose() {
    for (final c in names) c.dispose();
    super.dispose();
  }

  void start() {
    final players = [
      Player(names[0].text.trim().isEmpty ? 'اللاعب 1' : names[0].text.trim(), const Color(0xFF2E7D32)),
      Player(names[1].text.trim().isEmpty ? 'اللاعب 2' : names[1].text.trim(), const Color(0xFF1976D2)),
      Player(names[2].text.trim().isEmpty ? 'اللاعب 3' : names[2].text.trim(), const Color(0xFFF57C00)),
      Player(names[3].text.trim().isEmpty ? 'اللاعب 4' : names[3].text.trim(), const Color(0xFF7B1FA2)),
    ];
    Navigator.push(context, MaterialPageRoute(builder: (_) => GamePage(players: players)));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFF8F1DF), Color(0xFFE8D6AF)]),
          ),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(22),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 600),
                  child: Card(
                    elevation: 8,
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(children: [
                        const Text('🕌', style: TextStyle(fontSize: 72)),
                        const Text('الوصول إلى المسجد', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 8),
                        const Text('بالعلم .. نرتقي', style: TextStyle(fontSize: 18, color: Color(0xFF176B4D), fontWeight: FontWeight.bold)),
                        const SizedBox(height: 22),
                        const Text('أربعة لاعبين — البداية من الخانة 1 والهدف الخانة 50', textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
                        const SizedBox(height: 20),
                        for (int i = 0; i < 4; i++) ...[
                          TextField(
                            controller: names[i],
                            textAlign: TextAlign.right,
                            decoration: InputDecoration(labelText: 'اسم اللاعب ${i + 1}', prefixIcon: Icon(Icons.person, color: [const Color(0xFF2E7D32), const Color(0xFF1976D2), const Color(0xFFF57C00), const Color(0xFF7B1FA2)][i]), border: const OutlineInputBorder()),
                          ),
                          const SizedBox(height: 12),
                        ],
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(onPressed: start, icon: const Icon(Icons.play_arrow), label: const Padding(padding: EdgeInsets.all(12), child: Text('ابدأ اللعبة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))),
                        ),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GamePage extends StatefulWidget {
  const GamePage({super.key, required this.players});
  final List<Player> players;
  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  int current = 0;
  CardData? activeCard;
  int questionIndex = 0;
  final Map<int, bool> answered = {};
  bool showingCard = false;
  bool gameOver = false;
  final Map<int, String> eventMessages = {};

  PathType pathForPosition(int p) {
    if (p <= 17) return PathType.fiqh;
    if (p <= 34) return PathType.tawhid;
    return PathType.seerah;
  }

  Color pathColor(PathType p) {
    switch (p) {
      case PathType.fiqh: return const Color(0xFF2E7D32);
      case PathType.tawhid: return const Color(0xFF1976D2);
      case PathType.seerah: return const Color(0xFFF57C00);
    }
  }

  String pathName(PathType p) {
    switch (p) {
      case PathType.fiqh: return 'الفقه';
      case PathType.tawhid: return 'التوحيد';
      case PathType.seerah: return 'السيرة';
    }
  }

  String? specialText(int p) {
    switch (p) {
      case 8: return 'الصدق والإحسان\n+3';
      case 18: return 'كف الأذى وإماطته\n+3';
      case 31: return 'الكلمة الطيبة والتبسم\n+3';
      case 14: return 'إفشاء الأسرار وخيانة الأمانة\n-3';
      case 27: return 'الغيبة والنميمة\n-3';
      case 41: return 'عقوق الوالدين\n-3';
      default: return null;
    }
  }

  bool isGood(int p) => [8, 18, 31].contains(p);
  bool isBad(int p) => [14, 27, 41].contains(p);

  List<int> positions() => List.generate(50, (i) => i + 1);

  Future<void> chooseCard() async {
    final allowed = cards.where((c) => c.path == pathForPosition(widget.players[current].position)).toList();
    final card = allowed[math.Random().nextInt(allowed.length)];
    setState(() {
      activeCard = card;
      questionIndex = 0;
      answered.clear();
      showingCard = true;
    });
  }

  void answerQuestion(int answer) {
    if (answered.containsKey(questionIndex) || activeCard == null) return;
    final q = activeCard!.questions[questionIndex];
    final correct = answer == q.answer;
    final responder = (current + questionIndex + 1) % 4;
    setState(() {
      answered[questionIndex] = correct;
      if (correct) {
        widget.players[responder].score++;
        _movePlayer(responder, 1);
      }
    });
  }

  void _movePlayer(int index, int steps) {
    final p = widget.players[index];
    final old = p.position;
    p.position = math.min(50, math.max(1, p.position + steps));
    eventMessages[index] = 'تقدم ${p.position - old} خطوة';
    _applySpecial(index);
    if (p.position >= 50) gameOver = true;
  }

  void _applySpecial(int index) {
    final p = widget.players[index];
    final tile = p.position;
    if (isGood(tile)) {
      p.position = math.min(50, p.position + 3);
      eventMessages[index] = 'عمل صالح: +3 خطوات';
    } else if (isBad(tile)) {
      p.position = math.max(1, p.position - 3);
      eventMessages[index] = 'عمل سيئ: -3 خطوات';
    }
  }

  void nextQuestion() {
    if (activeCard == null) return;
    if (!answered.containsKey(questionIndex)) return;
    if (questionIndex < 2) {
      setState(() => questionIndex++);
    } else {
      setState(() {
        showingCard = false;
        activeCard = null;
        current = (current + 1) % 4;
      });
    }
  }

  void restart() {
    for (final p in widget.players) {
      p.position = 1;
      p.score = 0;
    }
    setState(() {
      current = 0;
      gameOver = false;
      activeCard = null;
      showingCard = false;
      answered.clear();
      eventMessages.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final cp = widget.players[current];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الوصول إلى المسجد', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          actions: [IconButton(onPressed: restart, tooltip: 'إعادة اللعبة', icon: const Icon(Icons.refresh))],
        ),
        body: Column(children: [
          _topBar(cp),
          Expanded(child: LayoutBuilder(builder: (context, constraints) => SingleChildScrollView(padding: const EdgeInsets.fromLTRB(12, 8, 12, 16), child: Column(children: [
            _board(constraints.maxWidth),
            const SizedBox(height: 12),
            if (!showingCard && !gameOver) _turnPanel(cp),
            if (showingCard && activeCard != null) _cardPanel(),
            if (gameOver) _winnerPanel(),
          ]))),
        ]),
      ),
    );
  }

  Widget _topBar(Player cp) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    decoration: const BoxDecoration(color: Color(0xFF176B4D)),
    child: Row(children: [
      const Icon(Icons.flag, color: Colors.white),
      const SizedBox(width: 8),
      Expanded(child: Text('دور ${cp.name} — الخانة ${cp.position}', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold))),
      Text('النهاية: 50', style: TextStyle(color: Colors.white.withOpacity(.9))),
    ]),
  );

  Widget _board(double width) {
    final boardW = math.min(width, 720.0);
    return Center(
      child: Container(
        width: boardW,
        height: boardW * .82,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFEAF3E2), Color(0xFFD7E7C8)]),
          border: Border.all(color: const Color(0xFF9A7B3E), width: 4),
          boxShadow: const [BoxShadow(blurRadius: 10, offset: Offset(0, 5), color: Colors.black26)],
        ),
        child: CustomPaint(
          painter: BoardPainter(widget.players),
          child: Stack(children: [
            Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: MosquePainter()))),
            ..._cellWidgets(boardW),
          ]),
        ),
      ),
    );
  }

  List<Widget> _cellWidgets(double w) {
    final result = <Widget>[];
    for (final p in positions()) {
      final xy = BoardPainter.cellCenter(p, w, w * .82);
      final r = specialText(p);
      final occupants = widget.players.where((x) => x.position == p).toList();
      result.add(Positioned(
        left: xy.dx - 18,
        top: xy.dy - 18,
        width: 36,
        height: 36,
        child: Tooltip(
          message: r ?? 'الخانة $p — مسار ${pathName(pathForPosition(p))}',
          child: Container(
            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.92), border: Border.all(color: pathColor(pathForPosition(p)), width: 2)),
            alignment: Alignment.center,
            child: Text('$p', style: TextStyle(fontSize: p >= 10 ? 10 : 12, fontWeight: FontWeight.w900, color: pathColor(pathForPosition(p)))),
          ),
        ),
      ));
      for (int i = 0; i < occupants.length; i++) {
        final pl = occupants[i];
        result.add(Positioned(left: xy.dx - 13 + (i % 2) * 18, top: xy.dy - 7 + (i ~/ 2) * 18, child: Container(width: 15, height: 15, decoration: BoxDecoration(color: pl.color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))));
      }
      if (r != null) {
        result.add(Positioned(left: xy.dx - 42, top: xy.dy - 39, width: 84, height: 34, child: Container(padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2), decoration: BoxDecoration(color: isGood(p) ? const Color(0xFF2E7D32) : const Color(0xFFB3261E), borderRadius: BorderRadius.circular(8), boxShadow: const [BoxShadow(blurRadius: 3, color: Colors.black26)]), child: Text(r, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 7.5, fontWeight: FontWeight.bold)))));
      }
    }
    return result;
  }

  Widget _turnPanel(Player cp) => Card(
    child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
      Text('المسار الحالي: ${pathName(pathForPosition(cp.position))}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: pathColor(pathForPosition(cp.position)))),
      const SizedBox(height: 8),
      const Text('أنت تسأل — اللاعبون الثلاثة الآخرون يجيبون على أسئلة البطاقة الثلاثة.', textAlign: TextAlign.center),
      const SizedBox(height: 12),
      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: chooseCard, icon: const Icon(Icons.style), label: const Text('اسحب بطاقة الأسئلة'))),
      const SizedBox(height: 8),
      const Text('كل إجابة صحيحة = خطوة واحدة للمجيب. ثم تنتقل الأدوار.', style: TextStyle(fontSize: 13)),
    ]),
  );

  Widget _cardPanel() {
    final card = activeCard!;
    final q = card.questions[questionIndex];
    final responder = widget.players[(current + questionIndex + 1) % 4];
    final answeredNow = answered.containsKey(questionIndex);
    final correct = answered[questionIndex] == true;
    return Card(
      color: const Color(0xFFFFFBF1),
      child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Chip(label: Text(pathName(card.path))),
          const SizedBox(width: 8),
          Expanded(child: Text(card.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          Text('${questionIndex + 1}/3'),
        ]),
        const SizedBox(height: 10),
        Text('السؤال إلى: ${responder.name}', style: TextStyle(color: responder.color, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(q.text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        for (int i = 0; i < q.options.length; i++) ...[
          Padding(padding: const EdgeInsets.only(bottom: 8), child: OutlinedButton(onPressed: answeredNow ? null : () => answerQuestion(i), child: Padding(padding: const EdgeInsets.all(9), child: Align(alignment: Alignment.centerRight, child: Text(q.options[i], style: const TextStyle(fontSize: 16))))),),
        ],
        if (answeredNow) ...[
          Text(correct ? 'إجابة صحيحة! +1 خطوة لـ ${responder.name}' : 'إجابة غير صحيحة — لا توجد خطوة هذه المرة.', style: TextStyle(fontWeight: FontWeight.bold, color: correct ? const Color(0xFF2E7D32) : const Color(0xFFB3261E))),
          if (eventMessages.containsKey(responder.hashCode)) const SizedBox.shrink(),
          const SizedBox(height: 10),
          FilledButton(onPressed: nextQuestion, child: Text(questionIndex == 2 ? 'إنهاء البطاقة وانتقال الدور' : 'السؤال التالي')),
        ],
      ])),
    );
  }

  Widget _winnerPanel() {
    final winner = widget.players.reduce((a, b) => a.position >= b.position ? a : b);
    return Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      const Text('🕌', style: TextStyle(fontSize: 58)),
      const Text('وصلنا إلى المسجد!', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text('${winner.name} وصل إلى الخانة ${winner.position} وهو المتصدر في الوصول.', textAlign: TextAlign.center),
      const SizedBox(height: 14),
      FilledButton.icon(onPressed: restart, icon: const Icon(Icons.replay), label: const Text('العبوا من جديد')),
    ]));
  }
}

class BoardPainter extends CustomPainter {
  BoardPainter(this.players);
  final List<Player> players;

  static Offset cellCenter(int n, double w, double h) {
    final t = (n - 1) / 49.0;
    final angle = t * math.pi * 6.4;
    final rx = w * .40 * (1 - .12 * t);
    final ry = h * .38 * (1 - .12 * t);
    final cx = w / 2 + rx * math.cos(angle);
    final cy = h / 2 + ry * math.sin(angle);
    return Offset(cx, cy);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path();
    for (int i = 1; i <= 50; i++) {
      final p = cellCenter(i, size.width, size.height);
      if (i == 1) path.moveTo(p.dx, p.dy); else path.lineTo(p.dx, p.dy);
    }
    canvas.drawPath(path, Paint()..color = Colors.white.withOpacity(.65)..style = PaintingStyle.stroke..strokeWidth = 44..strokeCap = StrokeCap.round);
    canvas.drawPath(path, Paint()..color = const Color(0xFF9B7A38)..style = PaintingStyle.stroke..strokeWidth = 3..strokeCap = StrokeCap.round);
    for (int i = 1; i < 50; i++) {
      final a = cellCenter(i, size.width, size.height);
      final b = cellCenter(i + 1, size.width, size.height);
      final p = Paint()..strokeWidth = 4..strokeCap = StrokeCap.round;
      if (i <= 16) p.color = const Color(0xFF2E7D32);
      else if (i <= 33) p.color = const Color(0xFF1976D2);
      else p.color = const Color(0xFFF57C00);
      canvas.drawLine(a, b, p);
    }
    final tp = TextPainter(textDirection: TextDirection.rtl);
    tp.text = const TextSpan(text: 'الوصول إلى المسجد', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF123E31)));
    tp.layout(maxWidth: size.width * .4);
    tp.paint(canvas, Offset(size.width * .30, 8));
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) => true;
}

class MosquePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2 + 10;
    final p = Paint()..color = const Color(0xFFF7E6C2)..style = PaintingStyle.fill;
    final edge = Paint()..color = const Color(0xFF9A7B3E)..style = PaintingStyle.stroke..strokeWidth = 3;
    final body = Rect.fromCenter(center: Offset(cx, cy + 28), width: size.width * .27, height: size.height * .24);
    canvas.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(18)), p);
    canvas.drawRRect(RRect.fromRectAndRadius(body, const Radius.circular(18)), edge);
    final dome = Path()..moveTo(cx - size.width * .10, cy + 2)..quadraticBezierTo(cx, cy - size.height * .12, cx + size.width * .10, cy + 2)..close();
    canvas.drawPath(dome, Paint()..color = const Color(0xFF176B4D));
    canvas.drawPath(dome, edge);
    for (final dx in [-.18, .18]) {
      final x = cx + size.width * dx;
      final tower = Rect.fromCenter(center: Offset(x, cy + 15), width: size.width * .045, height: size.height * .22);
      canvas.drawRect(tower, p);
      canvas.drawRect(tower, edge);
      canvas.drawCircle(Offset(x, cy - size.height * .105), size.width * .025, Paint()..color = const Color(0xFF176B4D));
    }
    final door = Rect.fromCenter(center: Offset(cx, cy + 65), width: size.width * .05, height: size.height * .09);
    canvas.drawRRect(RRect.fromRectAndRadius(door, const Radius.circular(18)), Paint()..color = const Color(0xFF6D4C41));
  }
  @override
  bool shouldRepaint(covariant MosquePainter oldDelegate) => false;
}
