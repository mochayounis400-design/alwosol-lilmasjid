package com.example.alwosollilmasjid

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
